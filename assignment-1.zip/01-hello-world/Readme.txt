Assignment-1.rmd file contains the solution.

Here are some recommended things to be done:

- Install below required packages

library(readr)
library(knitr)
library(tidyverse)
library(kableExtra)
library(dplyr)
library(broom)

give it a run. if there is any error with cli, go to bottom-right, click on packages, then find cli. uninstall that one. then install the latest version. this should solve the problem

- Read the whole assignment-01 file. there are some places you need to change name and date. Usually at the beginning of the doc

- Read slides from Jan-20 and Jan 25, they have instructions how to run this.

- Question 4 and 6 needs to be edited. Add the appropriate answers.

- Run the whole file and also run different chunks. If you dont understand something, make questions and send all questions together in a mail.

- make another copy assignment-1-copy.rmd and edit that. keep assignment-1 unchanged. if something is broken in the copy file, we can refer to assignment-1